<?php $__env->startSection('content'); ?>


<form action="<?php echo e(route('user.update', [ 'id' => $user->id ] )); ?>" method="POST">
    <?php echo e(csrf_field()); ?>



    <div class="col-md-8">

    	<div class="form-group">
    		<label>Edit Name</label>
			<input type="text" class="form-control"  name="name" value="<?php echo e($user->name); ?>">
		</div>

    	<div class="form-group">
    		<label>Edit Email</label>
			<input type="text" class="form-control"  name="email" value="<?php echo e($user->email); ?>">
		</div>

		<div class="form-group">
			<input type="text" class="form-control" placeholder="Update User Password (optional)" name="password">
		</div>

	</div>

	<div class="col-md-4">

		<div class="form-group">
			<label>Edit Status <span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span></label>
			<select name="completed" class="form-control">
				<?php if( $user->admin == 0 ): ?>
			  		<option value="0" selected>Not Active</option>
			  		<option value="1">Active</option>
			  	<?php else: ?>
			  		<option value="0">Not Active</option>
			  		<option value="1" selected>Active</option>
			  	<?php endif; ?>
			</select>
		</div>

        <div class="form-group">
            <label>Jabatan <span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span></label>
            <select name="" class="form-control">
              <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

		<div class="btn-group">
			<input class="btn btn-primary" type="submit" value="Submit">
			<a class="btn btn-default" href="<?php echo e(redirect()->getUrlGenerator()->previous()); ?>">Go Back</a>
		</div>

	</div>




</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>