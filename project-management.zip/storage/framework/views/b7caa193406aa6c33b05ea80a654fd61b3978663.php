<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <h1>USERS</h1>
    </div>
</div>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add user')): ?>
  <div class="new_project">
    <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>&nbsp;Add New User</button>
  </div>

  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
          <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Enter User Information</h4>
          </div>

          <div class="modal-body">
          <form id="task_form" action="<?php echo e(route('user.store')); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                  <div class="col-md-7">
                      <label>Create new User <span class="glyphicon glyphicon-plus" aria-hidden="true"></span></label>

                          <div class="form-group">
                              <input type="text" class="form-control" placeholder="Enter User Full Name" name="name" value="<?php echo e(old('name')); ?>">
                          </div>

                          <div class="form-group">
                              <input type="text" class="form-control" placeholder="Enter User Email" name="email" value="<?php echo e(old('email')); ?>">
                          </div>

                          <div class="form-group">
                              <input type="text" class="form-control" placeholder="Enter User Password" name="password">
                          </div>

                  </div>
                  <div class="col-md-5">
                      <div class="form-group">
                          <label>Set Status <span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span></label>
                          <select name="admin" class="form-control">
                              <option value="0" selected>Disabled</option>
                              <option value="1">Active (default)</option>
                          </select>
                      </div>

                  </div>

                  <div class="col-md-5">
                      <div class="form-group">
                          <label>Jabatan <span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span></label>
                          <select name="" class="form-control">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>

                  </div>
              </div>

              <div class="modal-footer">
                  <input class="btn btn-primary" type="submit" value="Submit" >
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>


          </form>
         </div>

      </div>

    </div>
  </div>
  <!--  END modal  -->
<?php endif; ?>





<table class="table table-striped">
    <thead>
      <tr>
        <th>Nama</th>
        <th>Email</th>
        <th>Jabatan</th>
        <th>Aksi</th>
      </tr>
    </thead>

<?php if( !$users->isEmpty() ): ?>
    <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if( $user->id == 1 ): ?>  <?php continue; ?>
    <?php endif; ?>
      <tr>
        <td><a href="<?php echo e(route('user.list', ['id'=> $user->id] )); ?>"><?php echo e($user->name); ?></a></td>

        <td><?php echo e($user->email); ?></td>

        <td>
          <?php echo e($user->roles()->pluck('name')->implode(' ')); ?>

        </td>

        <td>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit user')): ?>
            <a href="<?php echo e(route('user.edit', ['id' => $user->id])); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete user')): ?>
            <a href="<?php echo e(route('user.delete', ['id' => $user->id])); ?>" class="btn btn-danger" Onclick="return ConfirmDelete();"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
          <?php endif; ?>
        </td>
      </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
<?php else: ?>
    <p><em>There are no users yet</em></p>
<?php endif; ?>


</table>



<?php $__env->stopSection(); ?>

<script>

function ConfirmDelete()
{
  var x = confirm("Are you sure? Deleting a User will also delete all tasks associated.");
  if (x)
      return true;
  else
    return false;
}




</script>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>