<?php $__env->startSection('content'); ?>


<h1>Menampilkan Hasil Untuk:  "<?php echo e($value); ?>" </h1>

<table class="table table-striped">
    <thead>
      <tr>
        <th>Karyawan</th>
        <th>Judul Task</th>
        <th>Prioritas</th>
        <th>Status</th>
        <th>Aksi</th>
      </tr>
    </thead>

<?php if( !$tasks->isEmpty() ): ?>
    <tbody>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if( $user->id == $task->user_id ): ?>
                  <a href="<?php echo e(route('user.list', [ 'id' => $user->id ])); ?>"><?php echo e($user->name); ?></a>
              <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td><?php echo e($task->task_title); ?> </td>
        <td>
            <?php if( $task->priority == 0 ): ?>
                <span class="label label-info">Normal</span>
            <?php else: ?>
                <span class="label label-danger">Mendesak</span>
            <?php endif; ?>
        </td>
        <td>
            <?php if( !$task->completed ): ?>
                <a href="<?php echo e(route('task.completed', ['id' => $task->id])); ?>" class="btn btn-warning"> Mark as completed</a>
            <?php else: ?>
                <span class="label label-success">Selesai</span>
            <?php endif; ?>
        </td>
        <td>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit task')): ?>
            <!-- <a href="<?php echo e(route('task.edit', ['id' => $task->id])); ?>" class="btn btn-primary"> edit </a> -->
          <?php endif; ?>
            <a href="<?php echo e(route('task.view', ['id' => $task->id])); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete task')): ?>
            <a href="<?php echo e(route('task.delete', ['id' => $task->id])); ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
          <?php endif; ?>

        </td>
      </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
<?php else: ?>
    <p><em>Tidak Ditemukan</em></p>
<?php endif; ?>


</table>



    <div class="btn-group">
        <a class="btn btn-default" href="<?php echo e(redirect()->getUrlGenerator()->previous()); ?>">Kembali</a>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>